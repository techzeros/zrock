        <!-- begin #sidebar -->
		<div id="sidebar" class="sidebar">
			<!-- begin sidebar scrollbar -->
			<div data-scrollbar="true" data-height="100%">
				<!-- begin sidebar user -->
				<ul class="nav">
					<li class="nav-profile">
						<div class="image">
							<img src="<?php echo e(asset('portal/img/user.jpg')); ?>" alt="" />
						</div>
						<div class="info">
							<?php echo e(Auth::user()->name); ?> <br />
							<small><?php echo e(Auth::user()->email); ?></small>
						</div>
					</li>
				</ul>


				<!-- end sidebar user -->
				<!-- begin sidebar nav -->
				<ul class="nav">
					<li><a href="<?php echo e(url('app/dashboard')); ?>"><i class="material-icons">home</i> <span><?php echo app('translator')->getFromJson('user/dashboard.menu_home'); ?></span></a></li>
					<li><a href="<?php echo e(url('app/wallet')); ?>"><i class="material-icons">credit_card</i> <span><?php echo app('translator')->getFromJson('user/dashboard.my_wallet'); ?></span></a></li>
					<li><a href="#"><i class="material-icons">assignment_returned</i> <span><?php echo app('translator')->getFromJson('user/dashboard.menu_deposit'); ?></span></a></li>
					<li><a href="#"><i class="material-icons">send</i> <span><?php echo app('translator')->getFromJson('user/dashboard.menu_withdraw'); ?></span></a></li>
					<li><a href="#"><i class="material-icons">history</i> <span><?php echo app('translator')->getFromJson('user/dashboard.menu_history'); ?></span></a></li>
					<li><a href="<?php echo e(url('app/transfer-bitcoins')); ?>"><i class="material-icons">swap_horiz</i> <span><?php echo app('translator')->getFromJson('user/dashboard.transfer_bitcoins'); ?></span></a></li>
					<li><a href="<?php echo e(url('app/request-bitcoins')); ?>"><i class="material-icons">undo</i> <span><?php echo app('translator')->getFromJson('user/dashboard.request_bitcoins'); ?></span></a></li>
					<li><a href="#"><i class="material-icons">trending_up</i> <span><?php echo app('translator')->getFromJson('user/dashboard.menu_promotion'); ?></span></a></li>
					<li class="divider"></li>
					<li><a href="#"><i class="material-icons">settings</i> <span><?php echo app('translator')->getFromJson('user/dashboard.menu_settings'); ?></span></a></li>
					<li><a href="#"><i class="material-icons">help</i> <span>Help &amp; <?php echo app('translator')->getFromJson('user/dashboard.menu_help'); ?></span></a></li>
					<li>
						<?php $__env->startComponent('components.user.logout'); ?>
							<i class="material-icons">lock</i> <span><?php echo app('translator')->getFromJson('user/dashboard.menu_logout'); ?></span>
						<?php echo $__env->renderComponent(); ?>
					</li>
					
			        <!-- begin sidebar minify button -->
					<li><a href="javascript:;" class="sidebar-minify-btn" data-click="sidebar-minify"><i class="fa fa-angle-double-left"></i></a></li>
			        <!-- end sidebar minify button -->
				</ul>
				<!-- end sidebar nav -->
			</div>
			<!-- end sidebar scrollbar -->
		</div>
		<div class="sidebar-bg"></div>
		<!-- end #sidebar -->