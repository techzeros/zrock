<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class NanoSetting extends Model
{
    protected $table = 'nano_settings';
}
