<?php $__env->startSection('title', 'Wallet'); ?>

<?php $__env->startSection('content'); ?>

<?php 
$userid = Auth::user()->id;
?>

			<!-- begin row -->

			
				<div class="panel panel-default">
					<div class="panel-body">
					<h2><small><?php echo app('translator')->getFromJson('user/dashboard.addresses'); ?>; </small> 
						<span class="pull-right"><small><a href="#modal_new_address" class="btn btn-sm btn-success" data-toggle="modal">
							<i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson('user/dashboard.btn_5'); ?> </a></small></span></h2>
							<table class="table">
								<thead>
									<tr>
										<th><?php echo app('translator')->getFromJson('user/dashboard.label'); ?> </th>
										<th><?php echo app('translator')->getFromJson('user/dashboard.address'); ?> </th>
										<th><?php echo app('translator')->getFromJson('user/dashboard.balance'); ?> </th>
										<th><?php echo app('translator')->getFromJson('user/dashboard.action'); ?> </th>
									</tr>
								</thead>
								<tbody id="btc_addresses">
										<?php if($userAddresses->count() > 0): ?> 
										<?php $__currentLoopData = $userAddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
										<?php
										$user_name = camel_case(Auth::user()->name);
										$exp = 'usr_'.$user_name.'_';
										$expl = explode($exp,$Address->label);
										$total = '0.0000';	
									 											
										?> 
														
							
																		<tr id="btc_address_<?php echo e($Address->id); ?> ">
																			<td> 
																			
																			<?php echo e($expl[1]); ?>	
																		   </td>																		</td>
																			<td> <?php echo e($Address->address); ?>   </td>
																			<td> <?php echo e($Address->available_balance); ?>  BTC </td>
																			<td>
																				<a href="#modal_send_from_address" data-id="<?php echo e($Address->id); ?>" class="walletDialog btn btn-circle btn-sm btn-primary" data-toggle="modal" title="<?php echo app('translator')->getFromJson('user/dashboard.btn_6'); ?>"><i class="fa fa-arrow-circle-o-up" style="margin:0px;"></i></a>
																				<a class="walletDialog btn btn-circle btn-sm  btn-primary" data-id="<?php echo e($Address->id); ?>" href="#modal_receive_to_address" data-toggle="modal" title="<?php echo app('translator')->getFromJson('user/dashboard.btn_7'); ?>" ><i class="fa fa-arrow-circle-o-down" style="margin:0px;"></i></a> 
																				<a class="walletDialog btn btn-circle btn-sm  btn-primary" data-id="<?php echo e($Address->id); ?>" href="#btc_archive_address" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('user/dashboard.btn_9'); ?> "><i class="fa fa-archive" style="margin:0px;"></i></a>
																				<a class="walletDialog btn btn-circle btn-sm  btn-primary" data-id="<?php echo e($Address->id); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('user/dashboard.btn_10'); ?> " href="/app/transactions_by_address/<?php echo e($Address->address); ?> "><i class="fa fa-bars" style="margin:0px;"></i></a> 
																			</td>
																		</tr>
																	
																								
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
								<tr><td colspan="4">

										<div class="alert alert-warning">
												<?php echo app('translator')->getFromJson('user/dashboard.info_2'); ?> 
											</div>
										
								</td></tr> 
								<?php endif; ?>
								</tbody>
							</table>
					</div>
				</div>
				
				<div class="panel panel-default">
					<div class="panel-body">
					<h2><small><?php echo app('translator')->getFromJson('user/dashboard.latest_transactions'); ?> </small></h2>
							<div class="timeline">
									
									<?php if($userTransactions->count() > 0): ?> 
									<?php $__currentLoopData = $userTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
																	
																	 <!-- TIMELINE ITEM -->
																	<div class="timeline-item">
																		<div class="timeline-badge">
																			<?php if($query->type == "sent"): ?> 
																			<div style="margin-left:20px;margin-top:35px;font-size:16px;" class="text text-danger"><i class="fa fa-arrow-circle-o-up fa-3x"></i></div>
																			 <?php elseif($query->type == "received"): ?> 
																			<div style="margin-left:20px;margin-top:35px;font-size:16px;" class="text text-success"><i class="fa fa-arrow-circle-o-down fa-3x"></i></div>
																			 
																			  
																		</div>
																		<div class="timeline-body">
																			<div class="timeline-body-arrow"> </div>
																			<div class="timeline-body-head">
																				<div class="timeline-body-head-caption">
																					<a href="javascript:void(0);" class="timeline-body-title font-blue-madison">
																						<?php elseif($query->type == "sent"): ?> 
																						 <?php echo app('translator')->getFromJson('user/dashboard.sent'); ?>  
																						 <?php elseif($query->type == "received"): ?> 
																						<?php echo app('translator')->getFromJson('user/dashboard.received'); ?>  
																						
																						
																						
																						<?php echo e($query->amount); ?>  BTC</a>
																				</div>
																			<div class="timeline-body-content">
																				<span class="font-grey-cascade"> 
																					<?php echo app('translator')->getFromJson('user/dashboard.transaction_id'); ?> : 
																					<b><a href="https://chain.so/tx/BTC/<?php echo e($query->txid); ?>  "><?php echo e($query->txid); ?> 
																					 </a></b><br/>
																					<?php echo app('translator')->getFromJson('user/dashboard.sender'); ?> : <b><?php echo e($query->sender); ?></b><br/>
																					<?php echo app('translator')->getFromJson('user/dashboard.recipient'); ?> : <b><?php echo e($query->recipient); ?> </b><br/>
																					<?php echo app('translator')->getFromJson('user/dashboard.confirmations'); ?> : <b><?php echo e($query->confirmations); ?> </b><br/>
																					<?php echo app('translator')->getFromJson('user/dashboard.time'); ?> : <b><?php echo e(date("d/m/Y H:i",$query->time )); ?> </b>
																				</span>
																			</div>
																		</div>
																	</div>
																	<!-- END TIMELINE ITEM -->
																	
																
															<?php endif; ?>  
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php else: ?>
															<?php echo app('translator')->getFromJson('user/dashboard.info_6'); ?> 
															<?php endif; ?> 
															
															
														</div>
					</div>
				</div>
			<!-- end row -->
			<?php $__env->stopSection(); ?>


		<!-- #new address modal-dialog -->
		<div class="modal fade" id="modal_new_address">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
						<h4 class="modal-title" id="myModalLabel"><i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson('user/dashboard.new_address'); ?></h4>
					</div>

					<div class="modal-body">

							<div id="html_new_address_results"></div>
							<div id="html_new_address_form"></div>

						<form id="form_new_address">
							<p><?php echo app('translator')->getFromJson('user/dashboard.this_modal_create_address'); ?></p>
							<div class="form-group">
								<label><?php echo app('translator')->getFromJson('user/dashboard.label'); ?></label>
								<input type="text" class="form-control" name="label" placeholder="<?php echo app('translator')->getFromJson('user/dashboard.label_info'); ?>">
							</div>
							<p><?php echo app('translator')->getFromJson('user/dashboard.label_info_2'); ?></p>
							<button type="button" onclick="btc_submit_new_address();" class="btn btn-primary"><i class="fa fa-plus"></i><?php echo app('translator')->getFromJson('user/dashboard.btn_26'); ?></button>
						</form>
					</div>
					<div class="modal-footer">
						<a href="javascript:;" class="btn btn-sm btn-white" data-dismiss="modal">Close</a>
					</div>
				</div>
			</div>
		</div>




<?php $__currentLoopData = $userAddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
<?php
//current issue facing modal not dynamic, passing address id is war for now
$getAddressByAddressid = $Address->where('id', $Address->id)->get();
$total = $Address->available_balance;
$total = $total - 0.0008;
$total = $total - Setting::get('withdrawal_comission');
if($total < 0) { $total = '0.0000'; }	
										 
?>


<?php $__currentLoopData = $getAddressByAddressid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
																		<!-- #send_from_address modal-dialog -->
																		<div class="modal fade" id="modal_send_from_address">
																			<div class="modal-dialog">
																				<div class="modal-content">
																					<div class="modal-header">
																						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
																						<h4 class="modal-title"><i class="fa fa-arrow-circle-o-up"></i> <?php echo app('translator')->getFromJson('user/dashboard.send_bitcoins'); ?></h4>
																					</div>
																					<div class="modal-body">
																						<form id="form_new_address">
																								<div class="form-group">
																							<label><?php echo app('translator')->getFromJson('user/dashboard.from_wallet_address'); ?></label>
																							
																							<input type="text" class="form-control" disabled value="<?php echo e($expl[0]); ?> - <?php echo e($query->address); ?>">
																								<label><?php echo app('translator')->getFromJson('user/dashboard.label'); ?></label>
																							</div>
																
																
																					<div class="form-group">
																							<label><?php echo app('translator')->getFromJson('user/dashboard.to_wallet_address'); ?></label>
																							<input type="text" class="form-control" name="to_address">
																							<input type="text" hidden name="addrId" id="addrId" value=""/>
																						</div>
																
																
																					<div class="form-group">
																							<label><?php echo app('translator')->getFromJson('user/dashboard.amount'); ?></label>
																							<input type="text" class="form-control" name="amount" placeholder="0.000000">
																						</div>
																
																						
																					<button type="button" class="btn btn-primary"><?php echo app('translator')->getFromJson('user/dashboard.btn_6'); ?></button>
																					<span class="pull-right">
																							<?php echo app('translator')->getFromJson('user/dashboard.error_30'); ?>: <span id="btc_total"><?php echo e($total); ?></span> BTC
																					</span>	
																				</form>
																					</div>
																					<div class="modal-footer">
																						<a href="javascript:;" class="btn btn-sm btn-white" data-dismiss="modal">Close</a>
																					</div>
																				</div>
																			</div>
																		</div>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																
																		<?php $__currentLoopData = $getAddressByAddressid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
																		<!-- #receive_to_address modal-dialog -->
																		<div class="modal fade" id="modal_receive_to_address">
																			<div class="modal-dialog">
																				<div class="modal-content">
																					<div class="modal-header">
																						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
																						<h4 class="modal-title"><i class="fa fa-arrow-circle-o-up"></i> <?php echo app('translator')->getFromJson('user/dashboard.receive_bitcoins'); ?></h4>
																					</div>
																					<div class="modal-body">
																						<form id="btc_generate_qr_code">
																								<div class="form-group">
																							<label><?php echo app('translator')->getFromJson('user/dashboard.wallet_address'); ?></label>
																							
																							<input type="text" class="form-control" disabled value="<?php echo e($query->address); ?>">
																							</div>
																
																
																					<div class="form-group">
																							<label><?php echo app('translator')->getFromJson('user/dashboard.amount'); ?></label>
																							<input type="text" class="form-control" name="amount" placeholder="0.000000">
																						</div>
																
																						
																					<button type="button" class="btn btn-primary"><?php echo app('translator')->getFromJson('user/dashboard.btn_27'); ?></button>
																					
																				</form>
																
																			<div class="col-md-4">
																					<center><div id="btc_qr_code"></div></center>
																				</div>
																
																					</div>
																					<div class="modal-footer">
																						<a href="javascript:;" class="btn btn-sm btn-white" data-dismiss="modal">Close</a>
																					</div>
																				</div>
																			</div>
																		</div>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			

<?php $__env->startSection('custom_js'); ?>

$(document).on("click", ".walletDialog", function () {
	var putaddrId = $(this).data('id');
	$(".modal-body #addrId").val( putaddrId );
});

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>