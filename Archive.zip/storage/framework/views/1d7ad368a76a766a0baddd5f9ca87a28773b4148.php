<?php if(auth()->guard()->check()): ?>

<?php echo $__env->make('partials.user._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.user._begin-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
    <?php echo $__env->make('partials.user._topnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
    <?php echo $__env->make('partials.user._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.user._stats', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- begin #content -->
	<div id="content" class="content">
    <?php echo $__env->make('partials.user._alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
	</div>
		<!-- end #content -->
    <?php echo $__env->make('partials.user._end-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('partials.user._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php endif; ?>

<?php if(auth()->guard('admin')->check()): ?>
    <?php echo e('This is a dead end'); ?>

<?php endif; ?>