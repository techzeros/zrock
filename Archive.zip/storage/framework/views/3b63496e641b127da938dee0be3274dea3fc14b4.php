    
	<div id="page-container" class="fade page-sidebar-fixed page-header-fixed page-with-wide-sidebar">
		
		<div id="header" class="header navbar navbar-default navbar-fixed-top">
			
			<div class="container-fluid">
				
				<div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed navbar-toggle-left" data-click="sidebar-minify">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="<?php echo e(route('user.dashboard')); ?>" class="navbar-brand">
					    <?php echo e(config('app.name', 'NanoCoins')); ?>

					</a>
				</div>
				