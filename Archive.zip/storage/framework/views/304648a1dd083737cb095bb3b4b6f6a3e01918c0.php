<!DOCTYPE html>
<!--[if IE 8]> <html lang="<?php echo e(app()->getLocale()); ?>" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html lang="<?php echo e(app()->getLocale()); ?>">
<!--<![endif]-->

<head>
	<meta charset="utf-8" />
    
	<!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
	<title><?php echo e(config('app.name', 'NanoCoins')); ?> | <?php echo $__env->yieldContent('title'); ?></title>

    
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<meta content="NanoCoins Cryptocurrency Platform" name="description" />
	<meta content="NanoCoins, Currency, Cryptocurrency, blockchain, bitcoin, litcoin, Naira" name="keywords" />
    <meta content="NanoCoins Dev Team" name="author" />
	
	
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,400,400italic,500,500italic,700,700italic,900,900italic" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="<?php echo e(asset('portal/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('portal/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('portal/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('portal/css/animate.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('portal/css/style.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('portal/css/style-responsive.min.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('portal/css/theme/default.css')); ?>" rel="stylesheet" id="theme" />
	
	
	
    <link href="<?php echo e(asset('portal/plugins/jquery-jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('portal/plugins/bootstrap-calendar/css/bootstrap_calendar.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('portal/plugins/gritter/css/jquery.gritter.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('portal/plugins/morris/morris.css')); ?>" rel="stylesheet" />
	
	
    
    <?php echo $__env->yieldContent('custom_styles'); ?>

	
	<script src="<?php echo e(asset('portal/plugins/pace/pace.min.js')); ?>"></script>
	

</head>
<body>
	
	<div id="page-loader">
	    <div class="material-loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
            </svg>
            <div class="message">Loading...</div>
        </div>
	</div>
	