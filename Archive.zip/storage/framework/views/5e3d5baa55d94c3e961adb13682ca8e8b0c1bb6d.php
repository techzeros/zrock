                
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown navbar-user">
						<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
							<img src="<?php echo e(asset('portal/img/user.jpg')); ?>" alt="" /> 
							<span class="hidden-xs">Hi, <?php echo e(Auth::user()->name); ?></span>
						</a>
						<ul class="dropdown-menu animated fadeInLeft">
							<li class="arrow"></li>
							<li><a href="javascript:;">Settings</a></li>
							<li><a href="javascript:;">Deposit</a></li>
                            <li><a href="javascript:;">Withdraw</a></li>
                            <li><a href="javascript:;">Transactions</a></li>
							<li class="divider"></li>
                            <li>
                                <?php $__env->startComponent('components.user.logout'); ?>
                                    Logout
                                <?php echo $__env->renderComponent(); ?>
                            </li>
						</ul>
					</li>
				</ul>
                
            </div>
			
		</div>
		