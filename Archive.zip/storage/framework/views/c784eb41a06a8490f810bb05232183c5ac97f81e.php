<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

			
			<!-- begin row -->
			<div class="row">
			    <div class="col-md-8">
			        <div class="widget-chart with-sidebar bg-grey-900">
			            <div class="widget-chart-content">
			                <h4 class="chart-title">
			                    Bitcoin Market Price (USD) Analytics
			                    <small>Average USD market price across major bitcoin exchanges.</small>
			                </h4>
			                <div id="nano-bitcoinmarket-line-chart" class="morris-inverse"  style="height: 260px; width: 600px;"></div>
						</div>
						
			        </div>
			    </div>
			    <div class="col-md-4">
			        <div class="panel panel-inverse" data-sortable-id="index-1">
			            <div class="panel-heading">
			                <h4 class="panel-title">
			                   Total Bitcoin This Month(USD)
			                </h4>
			            </div>
			            <div id="bitcointotal-donut-chart" class="bg-black" style="height: 295px;"></div>
			             
			        </div>
			    </div>
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>