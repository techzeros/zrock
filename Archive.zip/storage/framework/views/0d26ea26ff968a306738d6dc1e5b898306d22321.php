    
    <?php $__env->startSection('title', 'Sign Up'); ?>

    <?php $__env->startSection('custom_styles'); ?>
        <!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
        <link href="<?php echo e(asset('portal/plugins/parsley/src/parsley.css')); ?>" rel="stylesheet" />
        <!-- ================== END PAGE LEVEL STYLE ================== -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('auth-news-feed'); ?>
        <!-- begin register -->
        <div class="register register-with-news-feed">
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('content'); ?>
                <!-- begin register-header -->
                <h1 class="register-header">
                    Sign Up
                    <small class="text-info">Create your <?php echo e(config('app.name', 'NanoCoins')); ?> Account. It’s free and always will be.</small>
                </h1>
                <!-- end register-header -->
                <!-- begin register-content -->
                <div class="register-content">
                    <form data-parsley-validate="true" class="margin-bottom-0" method="POST" action="<?php echo e(route('register.user')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <label class="control-label" for="name">Name <span class="text-danger">*</span></label>
                        <div class="row m-b-15<?php echo e($errors->has('name') ? ' has-error has-feedback' : ''); ?>">
                            <div class="col-md-12">
                                <input class="form-control" type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" data-type="alphanum" placeholder="Name"  data-parsley-required="true" />
                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <label class="control-label" for="email">Email <span class="text-danger">*</span></label>
                        <div class="row m-b-15<?php echo e($errors->has('email') ? ' has-error has-feedback' : ''); ?>">
                            <div class="col-md-12">
                                <input class="form-control" type="text" id="email" name="email" value="<?php echo e(old('email')); ?>" data-parsley-type="email" placeholder="Email" data-parsley-required="true" />
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <label class="control-label" for="password">Password <span class="text-danger">*</span></label>
                        <div class="row m-b-15<?php echo e($errors->has('password') ? ' has-error has-feedback' : ''); ?>">
                            <div class="col-md-12">
                                <input class="form-control" type="password" id="password" name="password" placeholder="Password" data-parsley-required="true" />
                                <?php if($errors->has('password')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <label class="control-label" for="password_confirmation">Confirm Password <span class="text-danger">*</span></label>
                        <div class="row m-b-15">
                            <div class="col-md-12">
                                <input class="form-control" type="password" id="password_confirmation" name="password_confirmation" placeholder="Password" data-parsley-equalto="#password" data-parsley-required="true" />
                            </div>
                        </div>
                        <div class="checkbox m-b-30">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" id="acceptedPolicy" name="acceptedPolicy" value="1" required />
                                    By clicking Sign Up, you agree to our <a href="#">Terms</a> and that you have read our <a href="#">Data Policy</a>, including our <a href="#">Cookie Use</a>.
                                </label>
                            </div>
                        </div>
                        <div class="register-buttons">
                            <button type="submit" class="btn btn-info btn-block btn-lg">Sign Up</button>
                        </div>
                        <div class="m-t-20 m-b-40 p-b-40 text-inverse">
                            Already a member? Click <a href="<?php echo e(route('user.login.form')); ?>">here</a> to login.
                        </div>
                        <hr />
                        <p class="text-center">
                            &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'NanoCoins')); ?> | All Right Reserved.
                        </p>
                    </form>
                </div>
                <!-- end register-content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('custom_js'); ?>
        <!-- ================== BEGIN PAGE LEVEL JS ================== -->
        <script src="<?php echo e(asset('portal/plugins/parsley/dist/parsley.js')); ?>"></script>
        <!-- ================== END PAGE LEVEL JS ================== -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>