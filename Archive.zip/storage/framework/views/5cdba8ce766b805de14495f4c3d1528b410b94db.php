    
    <?php $__env->startSection('title', 'Log In'); ?>

    <?php $__env->startSection('custom_styles'); ?>
        <!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
        <link href="<?php echo e(asset('portal/plugins/parsley/src/parsley.css')); ?>" rel="stylesheet" />
        <!-- ================== END PAGE LEVEL STYLE ================== -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('auth-news-feed'); ?>
        <!-- begin login -->
        <div class="login login-with-news-feed">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
                <!-- begin login-header -->
                <div class="login-header">
                    <div class="brand">
                        <span class="logo"></span> Login
                        <small>provide valid email and password</small>
                    </div>
                    <div class="icon">
                        <i class="material-icons">lock</i>
                    </div>
                </div>
                <!-- end login-header -->

                <!-- begin login-content -->
                <div class="login-content">

                    <?php if(\Session::has('message')): ?>
                        <div class="alert alert-success fade in m-b-15">
                             <strong><?php echo e(session('message')); ?></strong>
                            <span class="close" data-dismiss="alert">×</span>
                        </div>
                    <?php endif; ?>
                    
                    <form data-parsley-validate="true" class="margin-bottom-0" method="POST" action="<?php echo e(route('login.user')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group m-b-15<?php echo e($errors->has('email') ? ' has-error has-feedback' : ''); ?>">
                            <input type="email" class="form-control input-lg" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>" data-type="email" data-parsley-required="true" />
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group m-b-15<?php echo e($errors->has('password') ? ' has-error has-feedback' : ''); ?>">
                            <input type="password" class="form-control input-lg" name="password" placeholder="Password" data-parsley-required="true" />
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="checkbox m-b-30">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> > Remember Me
                                </label>
                            </div>
                        </div>
                        <div class="register-buttons">
                            <button type="submit" class="btn btn-info btn-block btn-lg">Login</button>
                        </div>
                        <br />
                        <div>
                            <a href="<?php echo e(route('password.request.form')); ?>" class="btn btn-white btn-block">Forgot Your Password?</a>
                        </div>
    
                        <div class="m-t-20 m-b-40 p-b-40 text-inverse">
                            Don't have an Account? Click <a href="<?php echo e(route('user.registration.form')); ?>">here</a> to register.
                        </div>
                        <hr />
                        <p class="text-center">
                            &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'NanoCoins')); ?> | All Right Reserved.
                        </p>
                    </form>
                </div>
                <!-- end login-content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('custom_js'); ?>
        <!-- ================== BEGIN PAGE LEVEL JS ================== -->
        <script src="<?php echo e(asset('portal/plugins/parsley/dist/parsley.js')); ?>"></script>
        <!-- ================== END PAGE LEVEL JS ================== -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>