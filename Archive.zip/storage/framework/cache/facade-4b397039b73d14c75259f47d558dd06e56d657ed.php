<?php

namespace Facades\App\Helpers;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Helpers\NanoHelper
 */
class NanoHelper extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'App\Helpers\NanoHelper';
    }
}
